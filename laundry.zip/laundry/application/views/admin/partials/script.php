<script src="<?= asset_url('admin/js/jquery.min.js') ?>"></script>
<script src="<?= asset_url('admin/js/bootstrap.min.js') ?>"></script>
<script src="<?= asset_url('admin/js/datatables.min.js') ?>"></script>
<script src="<?= asset_url('admin/js/dataTables.bootstrap.min.js') ?>" ></script>
<script src="<?= asset_url('admin/sweetalert/dist/sweetalert.min.js') ?>"></script>