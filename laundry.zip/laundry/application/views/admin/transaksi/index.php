<?php $this->load->view('admin/partials/header_v2') ?>

<div class="x_panel">
<div class="container">
	<h4 style="color: rgba(52, 73, 94, 0.88)"><strong>Data Transaksi</strong></h4>
	<hr style="border-top: 2px solid;">
	<div class="tombol">
		<a href="<?= route_url('admin/transaksi/tambah') ?>"><button type="button" class="btn btn-info btn-md" style="background-color: rgba(52, 73, 94, 0.88); border-color: : rgba(52, 73, 94, 0.88);"><i class="fa fa-plus"> Tambah Data </i></button></a>
	</div>
	<br>
	<div class="x_content">
		<table id="table" class="table table-striped jambo_table">
			<thead>
				<tr width="100%">
					<th width="3%" style="text-align: center;">No</th>
					<th width="5%">No. Order</th>
					<th width="22%">Nama</th>
					<th width="10%">Tanggal Terima</th>
					<th width="10%">Tanggal Ambil</th>
					<th width="5%">Berat(kg)</th>
					<th width="10%">Diskon</th>
					<th width="10%">Total Bayar</th>
					<th width="26%" style="text-align: center;">Aksi</th>
				</tr>
			</thead>
			<tbody>
        <?php foreach($transaksi as $i => $data): ?>
          <tr>
            <td style="text-align: center;"><?= $i + 1 ?></td>
            <td><?= $data->No_Order ?></td>
            <td><?= $data->Nama ?></td>
            <td><?= $data->Tgl_Terima ?></td>
            <td><?= $data->Tgl_Ambil ?></td>
            <td><?= $data->total_berat ?></td>
            <td><?= $data->diskon ?></td>
            <td align="right">Rp <?= $data->Total_Bayar ?></td>
			      <td style="text-align: center;">
              <?= form_open( route_url('admin/transaksi/:id/confirm', ['id' => $data->No_Order]), ['style' => 'display: inline-table'] ) ?>
                <button type="submit" class="btn btn-primary" style="font-size: 8pt;"><i class="fa fa-phone"></i></button>
              </form>
              <a style="font-size: 8pt;" href="<?= route_url('admin/cetak/struk/:id', ['id' => $data->No_Order]) ?>" class="btn btn-info" target="_blank"><i class="fa fa-print"></i></a>
              <a style="font-size: 8pt;" href="<?= route_url('admin/transaksi/:id/edit', ['id' => $data->No_Order]) ?>" class="btn btn-warning"><i class="fa fa-pencil"></i></a>
              <?= form_open( route_url('admin/transaksi/:id/delete', ['id' => $data->No_Order]), ['style' => 'display: inline'] ) ?>
                <button type="submit" class="btn btn-danger" style="font-size: 8pt;"><i class="fa fa-trash"></i></button>
              </form>
            </td>
          </tr>
        <?php endforeach ?>
			</tbody>
		</table>
	</div>
	<br>
	<br>
	<br>
</div>
</div>

<?php $this->load->view('admin/components/script_v2') ?>

<script>
	$(document).ready(function () {
		$('#table').DataTable();
	});
</script>

<?php $this->load->view('admin/partials/footer_v2') ?>
