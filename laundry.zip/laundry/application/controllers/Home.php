<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends MY_Controller {
    
    public function index()
    {
        return $this->view('home');
    }
}

// $this->db->query("SELECT * FROM transaksi INNER JOIN pengaduan ON transaksi.No_Order = pengaduan.No_Order");