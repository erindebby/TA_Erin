</body>
<footer>
        <p class="pull-right">Sistem Informasi Afika Laundry | ©2020 All Rights Reserved.</p>
</footer>
</html>