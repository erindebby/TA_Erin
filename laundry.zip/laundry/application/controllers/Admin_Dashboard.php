<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_Dashboard extends Admin_Controller {

    public function index()
    {
        return $this->view('home');
    }
}