<?php $this->load->view('admin/partials/header_v2') ?>

<div class="x_panel">
	<div class="x_title">
		<div class="container">
			<h4 style="color: rgba(52, 73, 94, 0.88)"><strong>Form Tambah Data Pengaduan</strong></h4>
      		<hr style="border-top: 2px solid;">
	</div>
		<?= validation_errors() ?>

	    <?= form_open(route_url('admin/pengaduan')) ?>
			<div class="form-group">
	          <label>Nomor Pengaduan</label>
	          <input type="text" class="form-control" name="No_Pengaduan" placeholder="Nomor Pengaduan" style="width: 250px">
	        </div>
			<div class="form-group">
				<label>Nomor Order</label>
				<input type="text" class="form-control" name="No_Order" placeholder="Nomor Order" style="width: 250px">
			</div>
			<div class="form-group">
				<label>Nomor Identitas</label>
				<input type="text" class="form-control" name="No_Identitas" placeholder="Nomor Identitas" style="width: 250px">
			</div>
			<div class="form-group">
				<label>Nama Pelanggan</label>
				<input type="text" class="form-control" name="Nama" placeholder="Nama Pelanggan" style="width: 250px">
			</div>
			<div class="form-group">
				<label>Keterangan</label>
				<textarea class="form-control" name="Keterangan" placeholder="Keterangan Pengaduan" style="width:1000px"></textarea>
			</div>
			<input type="submit" name="submit" value="Simpan" class="btn btn-success">
			<a href="<?= route_url('admin/pengaduan') ?>"><input type="button" class="btn btn-default" value="Batal"></a>
		</form>
	</div>
</div>
<?php $this->load->view('admin/components/script_v2') ?>
<?php $this->load->view('admin/partials/footer_v2') ?>
