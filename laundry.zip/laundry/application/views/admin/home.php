<?php $this->load->view('admin/partials/header_v2') ?>

<div class="x_panel"><h2>Selamat datang di Aplikasi Afika Laundry</h2></div>
<!-- /.row -->
<div class="row top_tiles">
    <!-- <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="tile-stats">
            <div class="icon"><i class="fa fa-comments-o"></i>
            </div>
            <div class="count">...</div><br/>

            <h3>Transaksi Masuk</h3>
        </div>
    </div>
    <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="tile-stats">
            <div class="icon"><i class="fa fa-comments-o"></i>
            </div>
            <div class="count">...</div><br/>

            <h3>Transaksi Keluar</h3>
        </div>
    </div> -->
    <!-- <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="tile-stats">
            <div class="icon"><i class="fa fa-comments-o"></i>
            </div>
            <div class="count">...</div><br/>
            <div class="count"><?php $query = $this->db->query("SELECT * FROM transaksi INNER JOIN pengaduan ON transaksi.No_Order = pengaduan.No_Order"); echo $query->num_rows(); ?></div><br/>
            <h3>Pengaduan</h3>
        </div>
    </div>
</div> -->


<?php $this->load->view('admin/components/script_v2') ?>
<?php $this->load->view('admin/partials/footer_v2') ?>