<!-- Scripts -->
<script src="<?= asset_url('v2/js/jquery.min.js') ?>"></script>
<script src="<?= asset_url('v2/js/bootstrap.min.js') ?>"></script>
<script src="<?= asset_url('v2/js/jquery.dataTables.min.js') ?>"></script>
<script src="<?= asset_url('v2/js/sweetalert.min.js') ?>"></script>
<script src="<?= asset_url('v2/js/nicescroll/jquery.nicescroll.min.js') ?>"></script>
<script src="<?= asset_url('v2/js/moment.min.js') ?>"></script>
<script src="<?= asset_url('v2/js/skycons/skycons.js') ?>"></script>
<script src="<?= asset_url('v2/js/custom.js') ?>"></script>
