<!DOCTYPE html>
<html lang="id">

<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Sistem Informasi Laundry</title>

	<!-- Bootstrap core CSS -->
	<link rel="stylesheet" href="<?= asset_url('v2/css/bootstrap.min.css') ?>" />
	<link rel="stylesheet" href="<?= asset_url('v2/fonts/css/font-awesome.min.css') ?>" />
	<link rel="stylesheet" href="<?= asset_url('v2/css/animate.min.css') ?>" />

	<!-- Custom styling plus plugins -->
	<link rel="stylesheet" href="<?= asset_url('v2/css/jquery.dataTables.min.css') ?>" />
	<link rel="stylesheet" href="<?= asset_url('v2/css/dataTables.bootstrap4.min.css') ?>" />
	<link rel="stylesheet" href="<?= asset_url('v2/css/sweetalert.css') ?>" />
	<link rel="stylesheet" href="<?= asset_url('v2/css/custom.css') ?>" />

	<!--[if lt IE 9]>
        <script src="../assets/js/ie8-responsive-file-warning.js"></script>
    <![endif]-->

	<!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
	<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->
</head>

<body class="nav-md">
	<div class="container body">
		<div class="main_container">
			<!-- Sidebar -->
			<?php $this->load->view('admin/components/sidebar_v2') ?>

			<!-- top navigation -->
			<?php $this->load->view('admin/components/navbar_v2') ?>

			<!-- page content -->
			<div class="right_col" role="main">
				<div class="row tile_count">
					<!-- This part onward will be filled by any pages that extends this partials -->
