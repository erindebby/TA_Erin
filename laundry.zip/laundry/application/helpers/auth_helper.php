<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if ( ! function_exists('is_authenticated'))
{
    function is_authenticated()
    {
        return isset($_SESSION['user']);
    }
}