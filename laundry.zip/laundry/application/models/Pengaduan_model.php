<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengaduan_model extends MY_Model {

    /** 
     * Nama tabel di database
     */
    protected $table = 'pengaduan';

    /**
     * Ambil semua data Pengaduan
     *
     * @return array
     */
    public function get()
    {
        return $this->db->get($this->table)->result();
    }

    /**
     * Cari satu data Pengaduan berdasarkan ID
     *
     * @param string $id
     * @return object
     */
    public function first($id)
    {
        return $this->db->get_where($this->table, [
            'No_Pengaduan' => $id
        ])->row();
    }

    //Tampilkan Detail Pengaduan
    public function choose($No_Order){
        $result=$this->db->get_where('No_Order', $No_Order)->limit(1)->get('pengaduan');
        if($result->num_rows() >0){
            return $result->row();
        }else{
            return false;
        }
    }

    /**
     * Insert data Pengaduan baru
     *
     * @param array $data
     * @return boolean
     */
    public function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }

    /**
     * Update data Pengaduan dengan ID
     *
     * @param string $id
     * @param array $data
     * @return boolean
     */
    public function update($id, $data)
    {
        return $this->db->update($this->table, $data, [
            'No_Pengaduan' => $id
        ]);
    }

    /**
     * Hapus data Pengaduan dengan ID
     *
     * @param string $id
     * @return boolean
     */
    public function delete($id)
    {
        return $this->db->delete($this->table, [
            'No_Pengaduan' => $id
        ]);
    }

    /**
     * Dapatkan Nomor Pengaduan selanjutnya
     *
     * @param string $id
     * @return boolean
     */
    public function get_pengaduan_number()
    {
        $last_pengaduan = $this->db
            ->select('No_Pengaduan')
            ->order_by('No_Pengaduan', 'desc')
            ->limit(1)
            ->get($this->table)->row();

        return intval($last_pengaduan->No_Pengaduan) + 1;
    }
}