<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pakaian_model extends MY_Model {

    /** 
     * Nama tabel di database
     */
    protected $table = 'pakaian';

    /**
     * Ambil semua data Pakaian
     *
     * @return array
     */
    public function get()
    {
        return $this->db->get($this->table)->result();
    }

    /**
     * Cari satu data Pakaian berdasarkan ID
     *
     * @param string $id
     * @return object
     */
    public function first($id)
    {
        return $this->db->get_where($this->table, [
            'Id_Pakaian' => $id
        ])->row();
    }

    /**
     * Insert data Pakaian baru
     *
     * @param array $data
     * @return boolean
     */
    public function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }

    /**
     * Update data Pakaian dengan ID
     *
     * @param string $id
     * @param array $data
     * @return boolean
     */
    public function update($id, $data)
    {
        return $this->db->update($this->table, $data, [
            'Id_Pakaian' => $id
        ]);
    }

    /**
     * Hapus data Pakaian dengan ID
     *
     * @param string $id
     * @return boolean
     */
    public function delete($id)
    {
        return $this->db->delete($this->table, [
            'Id_Pakaian' => $id
        ]);
    }
}