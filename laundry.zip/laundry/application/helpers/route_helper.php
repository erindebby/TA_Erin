<?php
defined('BASEPATH') OR exit('No direct script access allowed');

if ( ! function_exists('route_url'))
{
	function route_url($path, $params = [])
	{
        $url = base_url() . $path;

        foreach ($params as $key => $value) {
            $url = str_replace(":{$key}", $value, $url);
        }

        return $url;
    }
}