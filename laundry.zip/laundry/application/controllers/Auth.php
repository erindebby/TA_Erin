<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends MY_Controller {

    public function __construct()
    {
        parent::__construct();

        $this->load->model('admin_model');    
    }

    public function login()
    {
        if (is_authenticated()) {
            return redirect(route_url('admin'));
        }

        return $this->view('login');
    }

    public function post_login()
    {
        $email = $this->input->post('email');
        $pass = $this->input->post('pass');
        
        if (! $this->admin_model->attempt($email, $pass)) {
            die('login gagal');
        }

        return redirect(route_url('admin'));
    }

    public function logout()
    {
        $this->session->sess_destroy();

        return redirect(route_url('home'));
    }
}