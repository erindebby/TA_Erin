<?php $this->load->view('admin/partials/header_v2') ?>

<div class="container">
	<?= validation_errors() ?>

<div class="x_panel">
  <div class="x_title">
      <h2>Input Paket Laundry</h2>
      
      <div class="clearfix"></div>
  </div>
<div class="x_content">
  <div class="row">
    <div class="col-md-4">
      <?= form_open(route_url('admin/transaksi'), ['name' => 'form']) ?>
        <div class="form-group">
          <label>No. Order</label>
          <input type="text" class="form-control" name="No_Order" value="<?= $no_order ?>" readonly>
        </div>
        <div class="form-group">
          <label>Nama Pelanggan</label>
          <select class="form-control" name="No_Identitas">
            <?php foreach($pelanggan as $data): ?>
              <option value="<?= $data->No_Identitas ?>"><?= $data->Nama ?></option>
            <?php endforeach ?>
          </select>
        </div>
        <div class="form-group">
          <label>Total Berat</label>
          <input type="text" id="total_berat" class="form-control" name="total_berat" placeholder="Total Berat" value="0">
        </div>
        <div class="form-group">
          <label>Diskon</label>
          <input type="text" id="diskon" class="form-control" name="diskon" placeholder="Diskon" value="0" >
        </div>
        <div class="form-group">
          <label>Total Bayar</label>
          <input type="text"  class="form-control" name="total_bayar" readonly>
        </div>
        <input type="hidden" class="form-control" name="tanggal" value="<?= date('Y-m-d') ?>">
        <input type="button" value="Tampil Total Bayar" onClick="tambah()" class="btn btn-primary"/>
        <input type="submit" name="submit" value="Simpan" class="btn btn-success">
        <a href="<?= route_url('admin/transaksi') ?>"><input type="button" class="btn btn-default" value="Batal" ></a>
      </form>
    </div>
</div>
</div>
</div>

<div class="x_panel">
  <div class="x_title">
      <h2>Input Data Cucian</h2>
      
      <div class="clearfix"></div>
  </div>

    <div class="col-md-6 col-md-offset-2">
      <div id="pesan"></div>
      <div class="tombol" >
    		<button type="button" class="btn btn-success btn-md" data-toggle="modal" data-target="#ModalTambah" ><span class="glyphicon glyphicon-plus"></span>Tambah Detail Cucian</button>
    	</div>
      <br>
      <div class="table-responsive">
        <table id="table" class="table table-striped table-bordered" >
          <thead>
            <tr>
              <th style="text-align: center;">No</th>
              <th>Jenis Cucian</th>
              <th>Jumlah</th>
              <th style="text-align: center;" >Aksi</th>
            </tr>
          </thead>
          <tbody id="detail_trx">
            <?php foreach($detail_transaksi as $i => $dt): ?>
              <tr>
                <td style="text-align: center;"><?= $i + 1 ?></td>
                <td><?php echo $dt->Jenis_Pakaian ?></td>
                <td><?php echo $dt->Jumlah_pakaian ?></td>
                <td style="text-align: center;">
                <button type="submit" class="btn btn-danger" id="btn_delete" onClick="hapus('<?= $no_order ?>', '<?= $dt->Id_Pakaian ?>')">Hapus</button>
              </tr>
            <?php endforeach ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
</div>

<!-- Modal Tambah Data -->
<div class="modal fade" id="ModalTambah" role="dialog">
	<div class="modal-dialog modal-sm">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Tambah Transaksi Cucian</h4>
			</div>
			<div class="modal-body">
				<form id="tambah" method="POST" >
          <input type="text" class="form-control" name="No_Order" value="<?= $no_order ?>">
          <div class="form-group">
            <label>Jenis Cucian</label>
            <select class="form-control" name="Id_Pakaian">
              <?php foreach($pakaian as $data): ?>
                <option value="<?= $data->Id_Pakaian ?>"><?= $data->Jenis_Pakaian ?></option>
              <?php endforeach ?>
            </select>
          </div>
					<div class="form-group">
						<label>Jumlah</label>
						<input type="text" class="form-control" name="Jumlah_Pakaian" placeholder="Jumlah pakaian">
					</div>
					<div class="modal-footer">
						<button class="btn btn-success" type="submit">Simpan</button>
						<button class="btn btn-default" data-dismiss="modal" aria-hidden="true">Batal</button>
					</div>
				</form>
			</div>
		</div>
	</div>

<?php $this->load->view('admin/components/script_v2') ?>

<script type="text/javascript">
  function tambah() {
    a=eval(form.total_berat.value)
    b=eval(form.diskon.value)
    c=(a*7000)-b
    form.total_bayar.value=c
  }

  $('#tambah').submit(function() {
    let formData = $(this).serialize()
    let number = $('#detail_trx tr:last td:eq(0)').text()
    let noOrder = $('[name="No_Order"]').val()
    let idPakaian = $('[name="Id_Pakaian"] option:selected').val()
    let jenisPakaian = $('[name="Id_Pakaian"] option:selected').text()
    let jumlahPakaian = $('[name="Jumlah_Pakaian"]').val()

    if (number.length > 0) {
      number = parseInt(number) + 1
    } else {
      number = 1
    }

    $.ajax({
      type: 'POST',
      url: "<?= route_url('admin/transaksi/:order/detail', ['order' => $no_order]) ?>",
      dataType:"json",
      data: formData,
      success: function(data) {
        $("#pesan").addClass("css_pesan");
        $("#ModalTambah").modal('hide');
        $('#pesan').html('Sukses');

        if (data == 1) {
          $('#detail_trx').append(`
            <tr>
              <td style="text-align: center;">${number}</td>
              <td>${jenisPakaian}</td>
              <td>${jumlahPakaian}</td>
              <td style="text-align: center;">
              <button type="submit" class="btn btn-danger" id="btn_delete" onClick="hapus('${noOrder}', '${idPakaian}')">Hapus</button>
            </tr>
          `)
        }
      }
    })
    return false;
  });

  function hapus(order, id){
		swal({
			title: "Apa anda yakin?",
			text: "Anda tidak akan bisa mengembalikan data yang sudah terhapus!",
			type: "warning",
			showCancelButton: true,
			confirmButtonClass: "btn-danger",
			confirmButtonText: "Ya, hapus!",
			closeOnConfirm: false
    },
		function(){
			var no_id = id;
      var no_order = order;
			$.ajax({
				url: `<?= route_url('') ?>admin/transaksi/${no_order}/detail/${no_id}/delete`,
				type: "POST",
				success: function (data) {
          swal("Terhapus!", "Data berhasil dihapus.", "success")
          setTimeout(function(){ location.reload(); }, 1000)
        }
      });
		});
	};
</script>

<?php $this->load->view('admin/partials/footer_v2') ?>
