<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_Pelanggan extends Admin_Controller {

    public function __construct()
    {
        parent::__construct();

        $this->load->model('pelanggan_model');    
    }

    /**
     * Tampilkan semua data Pelanggan
     *
     * @return object
     */
    public function index()
    {
        $data['pelanggan'] = $this->pelanggan_model->get();

        return $this->view('pelanggan/index', $data);
    }

    /**
     * Tampilkan form insert data Pelanggan
     *
     * @return object
     */
    public function create()
    {
        return $this->view('pelanggan/create');
    }

    /**
     * Proses insert data Pelanggan
     *
     * @return object
     */
    public function store()
    {
        $this->pelanggan_model->insert([
            'No_Identitas' => $this->input->post('No_Identitas'),
            'Nama'      => $this->input->post('Nama'),
            'Alamat'    => $this->input->post('Alamat'),
            'No_Hp'     => $this->input->post('No_Hp')
        ]);

        return redirect(route_url('admin/pelanggan'));
    }

    /**
     * Tampilkan form update data Pelanggan
     *
     * @param string $id
     * @return object
     */
    public function edit($id)
    {
        $pelanggan = (array) $this->pelanggan_model->first($id);

        return $this->view_parse('pelanggan/edit', $pelanggan);
    }

    /**
     * Proses update data Pelanggan
     *
     * @param string $id
     * @return object
     */
    public function update($id)
    {
        $this->pelanggan_model->update($id, [
            'No_Identitas' => $this->input->post('No_Identitas'),
            'Nama'      => $this->input->post('Nama'),
            'Alamat'    => $this->input->post('Alamat'),
            'No_Hp'     => $this->input->post('No_Hp')
        ]);

        return redirect(route_url('admin/pelanggan'));
    }

    /**
     * Proses hapus data Pelanggan
     *
     * @param string $id
     * @return object
     */
    public function destroy($id)
    {
        $this->pelanggan_model->delete($id);

        return redirect(route_url('admin/pelanggan'));
    }
}