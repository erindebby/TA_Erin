<div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
	<div class="menu_section">
    <h3>Menu</h3>
    <ul class="nav side-menu">
      <li>
        <a href="<?= route_url('admin') ?>"><i class="fa fa-home"></i> Beranda</a>
      </li>
      <li>
        <a><i class="fa fa-book"></i> Master Data <span class="fa fa-chevron-down"></span></a>
        <ul class="nav child_menu" style="display: none">
          <li><a href="<?= route_url('admin/pakaian') ?>">Data Pakaian</a></li>
          <li><a href="<?= route_url('admin/pelanggan') ?>">Data Pelanggan</a></li> 
        </ul>
      </li>
      <li>
        <a><i class="fa fa-bar-chart"></i> Transaksi <span class="fa fa-chevron-down"></span></a>
        <ul class="nav child_menu" style="display: none">
          <li><a href="<?= route_url('admin/transaksi/tambah') ?>">Transaksi Baru</a></li>
          <li><a href="<?= route_url('admin/transaksi') ?>">Data Transaksi</a></li> 
        </ul>
      </li>
      <li>
        <a href="<?= route_url('admin/pengaduan') ?>"><i class="fa fa-edit"></i> Pengaduan</a>
      </li>
    </ul>
	</div>
</div>
