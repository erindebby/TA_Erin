<?php $this->load->view('admin/partials/header_v2') ?>

<div class="x_panel">
  <div class="x_title">
    <div class="container">
      <h4 style="color: rgba(52, 73, 94, 0.88)"><strong>Form Tambah Data Pelanggan</strong></h4>
      <hr style="border-top: 2px solid;">
    </div>
    	<?= validation_errors() ?>
      <?= form_open(route_url('admin/pelanggan')) ?>
        <div class="form-group">
            <label>No. Identitas</label>
            <input type="text" class="form-control" name="No_Identitas" placeholder="No. Identitas" style="width: 250px" >
          </div>
          <div class="form-group">
            <label>Nama</label>
            <input type="text" class="form-control" name="Nama" placeholder="Nama" style="width: 250px" >
          </div>
          <div class="form-group">
            <label>Alamat</label>
            <input type="text" class="form-control" name="Alamat" placeholder="Alamat" style="width: 250px" >
          </div>
          <div class="form-group">
            <label>No. Hp</label>
            <input type="text" class="form-control" name="No_Hp" placeholder="No. Hp" style="width: 250px" >
          </div>
        <input type="submit" name="submit" value="Simpan" class="btn btn-success" style="background-color: rgba(52, 73, 94, 0.88); border-color: : rgba(52, 73, 94, 0.88);">
        <a href="<?= route_url('admin/pelanggan') ?>"><input type="button" class="btn btn-default" value="Batal"></a>
    	</form>
    </div>
</div>

<?php $this->load->view('admin/components/script_v2') ?>
<?php $this->load->view('admin/partials/footer_v2') ?>
