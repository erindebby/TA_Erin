<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_Pengaduan extends Admin_Controller {

    public function __construct()
    {
        parent::__construct();

        $this->load->model('pengaduan_model');        
        $this->load->model('pelanggan_model');
        $this->load->model('transaksi_model');    
    }

    /**
     * Tampilkan semua data Pengaduan
     *
     * @return object
     */
    public function index()
    {
        $data['pengaduan'] = $this->pengaduan_model->get();

        return $this->view('pengaduan/index', $data);
    }

    /**
     * Tampilkan form insert data Pengaduan
     *
     * @return object
     */
    public function create()
    {
        $data['no_pengaduan'] = $this->pengaduan_model->get_pengaduan_number();

        return $this->view('pengaduan/create');
    }

    /**
     * Proses insert data Pengaduan
     *
     * @return object
     */

    public function store()
    {
        $this->pengaduan_model->insert([
            'No_Pengaduan' => $this->input->post('No_Pengaduan'),
            'No_Order' => $this->input->post('No_Order'),
            'No_Identitas' => $this->input->post('No_Identitas'),
            'Nama' => $this->input->post('Nama'),
            'Keterangan' => $this->input->post('Keterangan')
        ]);

        return redirect(route_url('admin/pengaduan'));
    }

    // Tampilkan detail Pengaduan
    public function detail($No_Order){
        $data['pengaduan'] = $this->pengaduan_model->get($No_Order);

        $this->view('pengaduan/create');

    }

    /**
     * Tampilkan form update data Pengaduan
     *
     * @param string $id
     * @return object
     */
    public function edit($id)
    {
        $pengaduan = $this->pengaduan_model->first($id);

        return $this->view_parse('pengaduan/edit', $pengaduan);
    }

    /**
     * Proses update data Pengaduan
     *
     * @param string $id
     * @return object
     */
    public function update($id)
    {
        $this->pengaduan_model->update($id, [
            'No_Pengaduan' => $this->input->post('No_Pengaduan'),
            'No_Order' => $this->input->post('No_Order'),
            'No_Identitas' => $this->input->post('No_Identitas'),
            'Nama' => $this->input->post('Nama'),
            'Keterangan' => $this->input->post('Keterangan')
        ]);
        return redirect(route_url('admin/pengaduan'));
    }

    /**
     * Proses hapus data Pakaian
     *
     * @param string $id
     * @return object
     */
    public function destroy($id)
    {
        $this->pengaduan_model->delete($id);

        return redirect(route_url('admin/pengaduan'));
    }
}