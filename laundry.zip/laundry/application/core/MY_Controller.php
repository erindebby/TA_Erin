<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {

    protected $baseAdmin = 'admin';
    
    public function view($content, $data = [])
    {
        return $this->load->view($content, $data);    
    }
}

class Admin_Controller extends MY_Controller {

    protected $baseAdmin = 'admin';

    public function __construct()
    {
        parent::__construct();

        if (! is_authenticated()) {
            return redirect(route_url('auth/login'));
        }

        $this->load->helper('form');
    }

    public function view($content, $data = [], $return = false)
    {
        return $this->load->view($this->baseAdmin . '/' . $content, $data, $return);
    }

    public function view_parse($content, $data = [])
    {
        $this->load->library('parser');

        return $this->parser->parse($this->baseAdmin . '/' . $content, $data);
    }
}