<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi_model extends MY_Model {

    /** 
     * Nama tabel di database
     */
    protected $table = 'transaksi';

    /**
     * Ambil semua data Transaksi
     *
     * @return array
     */
    public function get()
    {
        return $this->db->get($this->table)->result();
    }

    /**
     * Ambil semua data Transaksi dengan kondisi
     *
     * @return array
     */
    public function get_where($query)
    {
        return $this->db->get($this->table)->where($query)->result();
    }

    /**
     * Ambil semua data Transaksi dengan Pelanggan
     *
     * @return array
     */
    public function get_with_pelanggan()
    {
        return $this->db
            ->from($this->table)
            ->join('pelanggan', "pelanggan.No_Identitas = {$this->table}.No_Identitas")
            ->get()->result();
    }

    /**
     * Ambil semua data Transaksi dengan Pelanggan dan Kondisi
     *
     * @return array
     */
    public function get_with_pelanggan_where($query)
    {
        return $this->db
            ->from($this->table)
            ->join('pelanggan', "pelanggan.No_Identitas = {$this->table}.No_Identitas")
            ->where($query)
            ->get()->result();
    }

    /**
     * Cari satu data Transaksi berdasarkan ID
     *
     * @param string $id
     * @return object
     */
    public function first($id)
    {
        return $this->db->get_where($this->table, [
            'No_Order' => $id
        ])->row();
    }

    /**
     * Insert data Transaksi baru
     *
     * @param array $data
     * @return boolean
     */
    public function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }

    /**
     * Update data Transaksi dengan ID
     *
     * @param string $id
     * @param array $data
     * @return boolean
     */
    public function update($id, $data)
    {
        return $this->db->update($this->table, $data, [
            'No_Order' => $id
        ]);
    }

    /**
     * Hapus data Transaksi dengan ID
     *
     * @param string $id
     * @return boolean
     */
    public function delete($id)
    {
        $this->load->model('detail_transaksi_model');
        $this->detail_transaksi_model->delete_by_order($id);
        
        return $this->db->delete($this->table, [
            'No_Order' => $id
        ]);
    }

    /**
     * Dapatkan Nomor Order untuk transaksi selanjutnya
     *
     * @param string $id
     * @return boolean
     */
    public function get_order_number()
    {
        $last_order = $this->db
            ->select('No_Order')
            ->order_by('No_Order', 'desc')
            ->limit(1)
            ->get($this->table)->row();

        return intval($last_order->No_Order) + 1;
    }

    /**
     * Konfirmasi data Transaksi dengan ID
     *
     * @param string $id
     * @return boolean
     */
    public function confirm($id)
    {
        $data = ['Tgl_Ambil' => date('Y-m-d')];

        return $this->db->update($this->table, $data, [
            'No_Order' => $id
        ]);
    }
}