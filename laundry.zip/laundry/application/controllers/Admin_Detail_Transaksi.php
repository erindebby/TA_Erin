<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_Detail_Transaksi extends Admin_Controller {

    public function __construct()
    {
        parent::__construct();

        $this->load->library('form_validation');
        $this->load->model('detail_transaksi_model');
    }

    /**
     * Proses insert data Detail Transaksi
     *
     * @return object
     */
    public function store()
    {
        $this->form_validation->set_rules('No_Order','Nomor Order','required');
        $this->form_validation->set_rules('Id_Pakaian','ID Pakaian','required');
        $this->form_validation->set_rules('Jumlah_Pakaian','Jumlah Pakaian','required');

        if (! $this->form_validation->run()) {
            echo false;
        }

        echo $this->detail_transaksi_model->insert([
            'No_Order'  => $this->input->post('No_Order'),
            'Id_Pakaian'  => $this->input->post('Id_Pakaian'),
            'Jumlah_pakaian'   => $this->input->post('Jumlah_Pakaian')
        ]);
    }

    /**
     * Proses hapus data Transaksi
     *
     * @param string $id
     * @return object
     */
    public function destroy($order, $pakaian)
    {
        echo $this->detail_transaksi_model->delete($order, $pakaian);
    }
}