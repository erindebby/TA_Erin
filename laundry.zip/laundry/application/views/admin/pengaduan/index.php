<?php $this->load->view('admin/partials/header_v2') ?>

<div class="x_panel">
<div class="container">
	<h4 style="color: rgba(52, 73, 94, 0.88)"><strong>Data Pengaduan</strong></h4>
	<hr style="border-top: 2px solid;">
	<div class="tombol">
		<a href="<?= route_url('admin/pengaduan/tambah') ?>"><button type="button" class="btn btn-success btn-md"style="background-color: rgba(52, 73, 94, 0.88); border-color: : rgba(52, 73, 94, 0.88);"><i class="fa fa-plus"> Tambah Data </i></button></a>
	</div>
	<br>
	<div class="x_content">
	<div class="table-responsive">
		<table id="table" class="table table-striped responsive-utilities jambo_table">
			<thead>
				<tr>
					<th style="text-align: center;">Nomor Pengaduan</th>
					<th>Nomor Order</th>
					<th>Nomor Identitas</th>
					<th>Nama</th>
					<th>Keterangan</th>
					<th style="text-align: center;">Aksi</th>
				</tr>
			</thead>
			<tbody>
        <?php foreach($pengaduan as $i => $data): ?>
          <tr>
            <td><?= $data->No_Pengaduan ?></td>
            <td><?= $data->No_Order ?></td>
            <td><?= $data->No_Identitas ?></td>
            <td><?= $data->Nama ?></td>
            <td><?= $data->Keterangan ?></td>
            <td style="text-align: center;">

            <td><?php echo anchor('pengaduan/choose/'.$i->No_Pengaduan,'<div class="btn btn-sm btn-primary">Detail</div>')?></td>
            
              <a href="<?= route_url('admin/pengaduan/:No_Pengaduan/edit', ['id' => $data->No_Pengaduan]) ?>" class="btn btn-warning">Edit</a>
              <?= form_open( route_url('admin/pengaduan/:No_Pengaduan/delete', ['id' => $data->No_Pengaduan]), ['style' => 'display: inline'] ) ?>
                <button type="submit" class="btn btn-danger">Hapus</button>
              </form>
            </td>
          </tr>
        <?php endforeach ?>
			</tbody>
		</table>
	</div>
	</div>
	<br>
	<br>
	<br>
</div>
</div>

<?php $this->load->view('admin/components/script_v2') ?>

<script>
	$(document).ready(function () {
		$('#table').DataTable();
	});
</script>

<?php $this->load->view('admin/partials/footer_v2') ?>
