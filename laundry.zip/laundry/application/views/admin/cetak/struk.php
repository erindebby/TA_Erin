<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Struk Transaksi</title>
  <link rel="stylesheet" type="text/css" href="<?= asset_url('admin/css/bootstrap.min.css') ?>">
  <style media="screen">
    table, th, td, tr {
    border: 1px solid black;
    border-collapse: collapse;
  }
  th, td {
    padding: 5px;
    text-align: left;
  }
  hr {
    border: 1px solid black;
  }
  </style>
</head>
<body>
  <center>
    <h1>AFIKA LAUNDRY</h1>
    <h3>Laundry & Dry Cleaning</h3>
    <h3>Hp : 087 822 555 784</h3>
  </center>
  <hr>
  <div class="row">
    <div class="col-sm-6 col-xs-6">
      <p>
        Nama   : <?= $transaksi->Nama ?><br>
        Alamat : <?= $transaksi->Alamat ?>
      </p>
    </div>
    <div class="col-sm-6 col-xs-6">
      <p>Tgl Terima : <?= $transaksi->Tgl_Terima ?><br>
        Tgl Ambil   : <?= $tgl_akhir ?>
      </p>
    </div>
  </div>
  <hr>
  <p>No. Order : <?= $transaksi->No_Order ?></p>
  <div class="table-responsive">
  <table class="table" >
    <thead>
      <tr>
        <th>No</th>
        <th>Jenis Cucian</th>
        <th>Jumlah</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach($detail_transaksi as $i => $dt): ?>
        <tr>
          <td style="text-align:center"><?= $i + 1 ?></td>
          <td><?= $dt->Jenis_Pakaian ?></td>
          <td><?= $dt->Jumlah_pakaian ?></td>
        </tr>
      <?php endforeach ?>
    </tbody>
  </table>
  </div>
  <div>
    <p style="float:right">Total Bayar (Rp) : <?= $transaksi->Total_Bayar ?></p>
  </div>
  <div class="">
    <p>Total Berat : <?= $transaksi->total_berat ?>  Kg</p>
    <p>Diskon (Rp): <?= $transaksi->diskon ?></p>
  </div>
</body>
</html>