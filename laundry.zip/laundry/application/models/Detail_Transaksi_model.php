<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Detail_Transaksi_model extends MY_Model {

    /** 
     * Nama tabel di database
     */
    protected $table = 'detail_transaksi';

    /**
     * Ambil semua data Detail Transaksi
     *
     * @return array
     */
    public function get()
    {
        return $this->db->get($this->table)->result();
    }

    /**
     * Ambil semua data Detail Transaksi dengan Pakaian dan Kondisi
     *
     * @return array
     */
    public function get_with_pakaian_where($query)
    {
        return $this->db
            ->from($this->table)
            ->join('pakaian', "pakaian.Id_Pakaian = {$this->table}.Id_Pakaian")
            ->where($query)
            ->get()->result();
    }

    /**
     * Cari data Detail Transaksi berdasarkan Nomor Order
     *
     * @param string $id
     * @return object
     */
    public function getByOrderNumber($id)
    {
        return $this->db->get_where($this->table, [
            'No_Order' => $id
        ])->row();
    }

    /**
     * Insert data Detail Transaksi baru
     *
     * @param array $data
     * @return boolean
     */
    public function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }

    /**
     * Hapus data Detail Transaksi dengan Nomor Order dan ID Pakaian
     *
     * @param string $order
     * @param string $pakaian
     * @return boolean
     */
    public function delete($order, $pakaian)
    {
        return $this->db->delete($this->table, [
            'No_Order' => $order,
            'Id_Pakaian' => $pakaian
        ]);
    }

    /**
     * Hapus data Detail Transaksi dengan Nomor Order
     *
     * @param string $order
     * @return boolean
     */
    public function delete_by_order($order)
    {
        return $this->db->delete($this->table, [
            'No_Order' => $order
        ]);
    }
}