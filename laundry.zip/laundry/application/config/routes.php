<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	https://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There are three reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router which controller/method to use if those
| provided in the URL cannot be matched to a valid route.
|
|	$route['translate_uri_dashes'] = FALSE;
|
| This is not exactly a route, but allows you to automatically route
| controller and method names that contain dashes. '-' isn't a valid
| class or method name character, so it requires translation.
| When you set this option to TRUE, it will replace ALL dashes in the
| controller and method URI segments.
|
| Examples:	my-controller/index	-> my_controller/index
|		my-controller/my-method	-> my_controller/my_method
*/

$route['home']['get'] = 'home/index';
$route['auth/login']['post'] = 'auth/post_login';
$route['auth/logout']['get'] = 'auth/logout'; 
$route['auth/login']['get'] = 'auth/login';

$route['admin']['get'] = 'admin_dashboard/index';

$route['admin/pengaduan']['get'] = 'admin_pengaduan/index';
$route['admin/pengaduan']['post'] = 'admin_pengaduan/store';
$route['admin/pengaduan/tambah']['get'] = 'admin_pengaduan/create';
$route['admin/pengaduan/(:any)']['post'] = 'admin_pengaduan/update/$1';
$route['admin/pengaduan/(:any)/edit']['get'] = 'admin_pengaduan/edit/$1';
$route['admin/pengaduan/(:any)/delete']['post'] = 'admin_pengaduan/destroy/$1';

$route['admin/pakaian']['get'] = 'admin_pakaian/index';
$route['admin/pakaian']['post'] = 'admin_pakaian/store';
$route['admin/pakaian/tambah']['get'] = 'admin_pakaian/create';
$route['admin/pakaian/(:any)']['post'] = 'admin_pakaian/update/$1';
$route['admin/pakaian/(:any)/edit']['get'] = 'admin_pakaian/edit/$1';
$route['admin/pakaian/(:any)/delete']['post'] = 'admin_pakaian/destroy/$1';

$route['admin/pelanggan']['get'] = 'admin_pelanggan/index';
$route['admin/pelanggan']['post'] = 'admin_pelanggan/store';
$route['admin/pelanggan/tambah']['get'] = 'admin_pelanggan/create';
$route['admin/pelanggan/(:any)']['post'] = 'admin_pelanggan/update/$1';
$route['admin/pelanggan/(:any)/edit']['get'] = 'admin_pelanggan/edit/$1';
$route['admin/pelanggan/(:any)/delete']['post'] = 'admin_pelanggan/destroy/$1';

$route['admin/transaksi']['get'] = 'admin_transaksi/index';
$route['admin/transaksi']['post'] = 'admin_transaksi/store';
$route['admin/transaksi/tambah']['get'] = 'admin_transaksi/create';
$route['admin/transaksi/(:any)']['post'] = 'admin_transaksi/update/$1';
$route['admin/transaksi/(:any)/edit']['get'] = 'admin_transaksi/edit/$1';
$route['admin/transaksi/(:any)/confirm']['post'] = 'admin_transaksi/confirm/$1';
$route['admin/transaksi/(:any)/delete']['post'] = 'admin_transaksi/destroy/$1';
$route['admin/transaksi/(:any)/detail']['post'] = 'admin_detail_transaksi/store/$1';
$route['admin/transaksi/(:any)/detail/(:any)/delete']['post'] = 'admin_detail_transaksi/destroy/$1/$2';

$route['admin/cetak/struk/(:any)']['get'] = 'admin_cetak/struk/$1';

/**
 * Default CI routes
 */
$route['default_controller'] = 'home';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;
