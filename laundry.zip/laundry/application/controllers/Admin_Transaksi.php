<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_Transaksi extends Admin_Controller {

    public function __construct()
    {
        parent::__construct();

        $this->load->model('pakaian_model');
        $this->load->model('pelanggan_model');
        $this->load->model('transaksi_model');
        $this->load->model('detail_transaksi_model');
    }

    /**
     * Tampilkan semua data Transaksi
     *
     * @return object
     */
    public function index()
    {
        $data['transaksi'] = $this->transaksi_model->get_with_pelanggan();

        return $this->view('transaksi/index', $data);
    }

    /**
     * Tampilkan form insert data Transaksi
     *
     * @return object
     */
    public function create()
    {   
        $data['pelanggan'] = $this->pelanggan_model->get();
        $data['pakaian'] = $this->pakaian_model->get();
        $data['no_order'] = $this->transaksi_model->get_order_number();
        $data['detail_transaksi'] = $this->detail_transaksi_model->get_with_pakaian_where([
            'No_Order' => $data['no_order']
        ]);

        return $this->view('transaksi/create', $data);
    }

    /**
     * Proses insert data Transaksi
     *
     * @return object
     */
    public function store()
    {
        $this->transaksi_model->insert([
            'No_Order'  => $this->input->post('No_Order'),
            'No_Identitas'  => $this->input->post('No_Identitas'),
            'total_berat'   => $this->input->post('total_berat'),
            // 'diskon'        => $this->input->post('diskon'),
            'Total_Bayar'   => $this->input->post('total_bayar'),
            'Tgl_Terima'    => date('Y-m-d')
        ]);

        return redirect(route_url('admin/transaksi'));
    }

    /**
     * Tampilkan form update data Transaksi
     *
     * @param string $id
     * @return object
     */
    public function edit($id)
    {
        $data['no_order'] = $id;
        $data['transaksi'] = $this->transaksi_model->first($id);
        $data['pelanggan'] = $this->pelanggan_model->get();
        $data['pakaian'] = $this->pakaian_model->get();
        $data['detail_transaksi'] = $this->detail_transaksi_model->get_with_pakaian_where([
            'No_Order' => $id
        ]);

        return $this->view('transaksi/edit', $data);
    }

    /**
     * Proses update data Transaksi
     *
     * @param string $id
     * @return object
     */
    public function update($id)
    {
        $this->transaksi_model->update($id, [
            'No_Order'  => $this->input->post('No_Order'),
            'No_Identitas'  => $this->input->post('No_Identitas'),
            'total_berat'   => $this->input->post('total_berat'),
            'diskon'        => $this->input->post('diskon'),
            'Total_Bayar'   => $this->input->post('total_bayar')
        ]);

        return redirect(route_url('admin/transaksi'));
    }

    /**
     * Proses hapus data Transaksi
     *
     * @param string $id
     * @return object
     */
    public function destroy($id)
    {
        $this->transaksi_model->delete($id);

        return redirect(route_url('admin/transaksi'));
    }

    /**
     * Proses konfirmasi data Transaksi
     *
     * @param string $id
     * @return object
     */
    public function confirm($id)
    {
        $this->transaksi_model->confirm($id);

        return redirect(route_url('admin/transaksi'));
    }
}