<div class="col-md-3 left_col">
	<div class="left_col scroll-view">
		<div class="navbar nav_title" style="border: 0;">
			<a href="<?= route_url('admin') ?>" class="site_title"><span>Afika Laundry</span></a>
		</div>
		<div class="clearfix"></div>

		<!-- menu prile quick info -->
		<div class="profile">
			<div class="profile_pic">
				<img src="<?= asset_url('v2/images/picture.jpg') ?>" alt="..." class="img-circle profile_img">
			</div>
			<div class="profile_info">
				<span>Welcome,</span>
				<h2><?= $this->session->user->email ?></h2>
			</div>
		</div>

		<!-- sidebar menu -->
		<?php $this->load->view('admin/components/navbar_items_v2') ?>
	</div>
</div>
