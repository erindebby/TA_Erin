<?php $this->load->view('admin/partials/header_v2') ?>

<div class="x_panel">
	<div class="x_title>">
		<div class="container">
			<h4 style="color: rgba(52, 73, 94, 0.88)"><strong>Form Edit Data Pakaian</strong></h4>
          <hr style="border-top: 2px solid;">
	</div>
			<?= form_open(route_url('admin/pakaian/:id', ['id' => $Id_Pakaian])) ?>
				<div class="form-group">
					<label>Kode Pakaian</label>
					<input type="text" class="form-control" name="Id_Pakaian" placeholder="Kode Pakaian" style="width: 250px" readonly="readonly" value="{Id_Pakaian}">
				</div>
				<div class="form-group">
					<label>Jenis Pakaian</label>
					<input type="text" class="form-control" name="Jenis_Pakaian" placeholder="Jenis Pakaian" style="width: 250px" value="{Jenis_Pakaian}">
				</div>
				<input type="submit" name="submit" value="Simpan" class="btn btn-success" style="background-color: rgba(52, 73, 94, 0.88); border-color: : rgba(52, 73, 94, 0.88);">
				<a href="<?= route_url('admin/pakaian') ?>"><input type="button" class="btn btn-default" value="Batal"></a>
			</form>
		</div>
</div>

<?php $this->load->view('admin/components/script_v2') ?>
<?php $this->load->view('admin/partials/footer_v2') ?>
