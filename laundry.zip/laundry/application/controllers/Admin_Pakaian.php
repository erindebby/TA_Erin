<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_Pakaian extends Admin_Controller {

    public function __construct()
    {
        parent::__construct();

        $this->load->model('pakaian_model');    
    }

    /**
     * Tampilkan semua data Pakaian
     *
     * @return object
     */
    public function index()
    {
        $data['pakaian'] = $this->pakaian_model->get();

        return $this->view('pakaian/index', $data);
    }

    /**
     * Tampilkan form insert data Pakaian
     *
     * @return object
     */
    public function create()
    {
        return $this->view('pakaian/create');
    }

    /**
     * Proses insert data Pakaian
     *
     * @return object
     */
    public function store()
    {
        $this->pakaian_model->insert([
            'Id_Pakaian' => $this->input->post('Id_Pakaian'),
            'Jenis_Pakaian' => $this->input->post('Jenis_Pakaian')
        ]);

        return redirect(route_url('admin/pakaian'));
    }

    /**
     * Tampilkan form update data Pakaian
     *
     * @param string $id
     * @return object
     */
    public function edit($id)
    {
        $pakaian = $this->pakaian_model->first($id);

        return $this->view_parse('pakaian/edit', $pakaian);
    }

    /**
     * Proses update data Pakaian
     *
     * @param string $id
     * @return object
     */
    public function update($id)
    {
        $this->pakaian_model->update($id, [
            'Id_Pakaian' => $this->input->post('Id_Pakaian'),
            'Jenis_Pakaian' => $this->input->post('Jenis_Pakaian')
        ]);

        return redirect(route_url('admin/pakaian'));
    }

    /**
     * Proses hapus data Pakaian
     *
     * @param string $id
     * @return object
     */
    public function destroy($id)
    {
        $this->pakaian_model->delete($id);

        return redirect(route_url('admin/pakaian'));
    }
}