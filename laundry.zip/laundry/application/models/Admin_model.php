<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_model extends MY_Model {

    protected $table = 'admin';

    public function attempt($email, $pass)
    {
        $result = $this->db->get_where($this->table, [
            'email' => $email,
            'pass' => $pass
        ])->row();

        if ($result) {
            $this->session->user = $result;
        }

        return ($result ? true : false);
    }
}