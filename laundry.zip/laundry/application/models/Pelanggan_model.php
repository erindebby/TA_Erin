<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pelanggan_model extends MY_Model {

    /** 
     * Nama tabel di database
     */
    protected $table = 'pelanggan';

    /**
     * Ambil semua data Pelanggan
     *
     * @return array
     */
    public function get()
    {
        return $this->db->get($this->table)->result();
    }

    /**
     * Cari satu data Pelanggan berdasarkan ID
     *
     * @param string $id
     * @return object
     */
    public function first($id)
    {
        return $this->db->get_where($this->table, [
            'No_Identitas' => $id
        ])->row();
    }

    /**
     * Insert data Pelanggan baru
     *
     * @param array $data
     * @return boolean
     */
    public function insert($data)
    {
        return $this->db->insert($this->table, $data);
    }

    /**
     * Update data Pelanggan dengan ID
     *
     * @param string $id
     * @param array $data
     * @return boolean
     */
    public function update($id, $data)
    {
        return $this->db->update($this->table, $data, [
            'No_Identitas' => $id
        ]);
    }

    /**
     * Hapus data Pelanggan dengan ID
     *
     * @param string $id
     * @return boolean
     */
    public function delete($id)
    {
        return $this->db->delete($this->table, [
            'No_Identitas' => $id
        ]);
    }
}