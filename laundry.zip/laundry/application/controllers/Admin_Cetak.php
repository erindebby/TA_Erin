<?php

use Dompdf\Dompdf;

defined('BASEPATH') OR exit('No direct script access allowed');

require_once __DIR__ . '/../../vendor/dompdf/autoload.inc.php';

class Admin_Cetak extends Admin_Controller {

    protected $domPdf;

    public function __construct()
    {
        parent::__construct();
    
        $this->domPdf = new Dompdf();
        $this->load->model('transaksi_model');
        $this->load->model('detail_transaksi_model');
    }

    public function struk($order)
    {
        $order = ['No_Order' => $order];
        $data['transaksi'] = $this->transaksi_model->get_with_pelanggan_where($order)[0];
        $data['detail_transaksi'] = $this->detail_transaksi_model->get_with_pakaian_where($order);
        $data['tgl_akhir'] = date('Y-m-d', strtotime('+3 days', strtotime($data['transaksi']->Tgl_Terima)));

        $html = $this->view('cetak/struk', $data, true);

        $this->domPdf->set_paper("A5");
        $this->domPdf->load_html($html);
        $this->domPdf->render();
        
        return $this->domPdf->stream('struk.pdf');
    }
}