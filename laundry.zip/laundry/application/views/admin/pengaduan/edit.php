<?php $this->load->view('admin/partials/header_v2') ?>

<div class="container">
	<h3>Form Edit Data Pengaduan</h3>
	<hr>
	<br>
	<?= form_open(route_url('admin/pengaduan/:id', ['id' => $No_Pengaduan])) ?>
		<div class="form-group">
			<label>Nomor Pengaduan</label>
			<input type="text" class="form-control" name="No_Pengaduan" placeholder="NomoR Pengaduan" style="width: 250px" readonly="readonly" value="{No_Pengaduan}">
		</div>
		<div class="form-group">
			<label>Nomor Order</label>
			<input type="text" class="form-control" name="No_Order" placeholder="Nomor Order" style="width: 250px" value="{No_Order}">
		</div>
		<div class="form-group">
			<label>Nomor Identitas</label>
			<input type="text" class="form-control" name="No_Identitas" placeholder="Nomor Identitas" style="width: 250px" value="{No_Identitas}">
		</div>
		<div class="form-group">
			<label>Nama</label>
			<input type="text" class="form-control" name="Nama" placeholder="Nama Pelanggan" style="width: 250px" value="{Nama}">
		</div>
		<div class="form-group">
			<label>Keterangan</label>
			<input type="text" class="form-control" name="Keterangan" placeholder="Keterangan" style="width: 250px" value="{Keterangan}">
		</div>
		<input type="submit" name="submit" value="Simpan" class="btn btn-success">
		<a href="<?= route_url('admin/pengaduan') ?>"><input type="button" class="btn btn-default" value="Batal"></a>
	</form>
</div>

<?php $this->load->view('admin/components/script_v2') ?>
<?php $this->load->view('admin/partials/footer_v2') ?>
