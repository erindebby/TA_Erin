<?php $this->load->view('admin/partials/header_v2') ?>

<div class="x_panel">
<div class="container">
	<h4 style="color: rgba(52, 73, 94, 0.88)"><strong>Data Pakaian</strong></h4>
	<hr style="border-top: 2px solid;">
	<div class="tombol">
		<a href="<?= route_url('admin/pakaian/tambah') ?>"><button type="button" class="btn btn-success btn-md"style="background-color: rgba(52, 73, 94, 0.88); border-color: : rgba(52, 73, 94, 0.88);"><i class="fa fa-plus"> Tambah Data </i></button></a>
	</div>
	<br>
	<div class="x_content">
	<div class="table-responsive">
		<table id="table" class="table table-striped jambo_table">
			<thead>
				<tr>
					<th style="text-align: center;">No</th>
					<th>Kode Pakaian</th>
					<th>Jenis Pakaian</th>
					<th style="text-align: center;">Aksi</th>
				</tr>
			</thead>
			<tbody>
        <?php foreach($pakaian as $i => $data): ?>
          <tr>
            <td style="text-align: center;"><?= $i + 1 ?></td>
            <td><?= $data->Id_Pakaian ?></td>
            <td><?= $data->Jenis_Pakaian ?></td>
            <td style="text-align: center;">
              <a href="<?= route_url('admin/pakaian/:id/edit', ['id' => $data->Id_Pakaian]) ?>" class="btn btn-warning">Edit</a>
              <?= form_open( route_url('admin/pakaian/:id/delete', ['id' => $data->Id_Pakaian]), ['style' => 'display: inline'] ) ?>
                <button type="submit" class="btn btn-danger">Hapus</button>
              </form>
            </td>
          </tr>
        <?php endforeach ?>
			</tbody>
		</table>
	</div>
	</div>
	<br>
	<br>
	<br>
</div>
</div>

<?php $this->load->view('admin/components/script_v2') ?>

<script>
	$(document).ready(function () {
		$('#table').DataTable();
	});
</script>

<?php $this->load->view('admin/partials/footer_v2') ?>
